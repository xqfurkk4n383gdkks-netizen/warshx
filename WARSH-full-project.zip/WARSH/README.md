# 𝑾Á𝑹𝑺𝑯

Full-stack starter for the 𝑾Á𝑹𝑺𝑯 Free Fire sensitivity platform.

## Run

1. Install Node.js 18+.
2. Extract this folder.
3. Run:

```bash
npm install
npm run dev
```

Frontend: http://localhost:5173
Backend: http://localhost:3000

For production:

```bash
npm install
npm run build
npm start
```

Copy `.env.example` to `.env` and change the admin credentials and JWT secret.

## Important

The included engine is a deterministic local optimization engine, not a claim of guaranteed headshots and not a fake external AI response. External AI providers are intentionally not called until credentials and a provider implementation are configured.

The visitor system stores an anonymous visitor ID and technical request data. Browser APIs cannot reliably reveal a user's exact phone model; unknown values remain `UNKNOWN`.

TikTok OAuth, production music storage, and a production-grade external PostgreSQL deployment require their respective credentials/providers and should not be simulated.
