require("dotenv").config();
const express = require("express");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");
const path = require("path");
const crypto = require("crypto");
const http = require("http");
const { WebSocketServer } = require("ws");

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "warsh-development-secret";

app.use(cors());
app.use(express.json({ limit: "2mb" }));

const db = new Database(path.join(__dirname, "warsh.db"));
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS admins (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 email TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'admin',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS visitors (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 visitor_id TEXT UNIQUE NOT NULL,
 user_agent TEXT,
 os TEXT,
 browser TEXT,
 screen TEXT,
 brand TEXT,
 model TEXT,
 tiktok_connected INTEGER DEFAULT 0,
 first_visit TEXT DEFAULT CURRENT_TIMESTAMP,
 last_active TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS events (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 visitor_id TEXT NOT NULL,
 type TEXT NOT NULL,
 payload TEXT,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sensitivity_profiles (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 visitor_id TEXT,
 device TEXT,
 platform TEXT,
 playstyle TEXT,
 aim_speed TEXT,
 drag_style TEXT,
 control TEXT,
 target_priority TEXT,
 general INTEGER,
 red_dot INTEGER,
 scope_2x INTEGER,
 scope_4x INTEGER,
 sniper INTEGER,
 free_look INTEGER,
 dpi INTEGER,
 headshot_target INTEGER DEFAULT 85,
 optimization_score INTEGER,
 engine_version TEXT DEFAULT 'WARSH_ENGINE_V1',
 provider TEXT DEFAULT 'local',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS feedback (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 profile_id INTEGER,
 visitor_id TEXT,
 type TEXT NOT NULL,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS devices (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 brand TEXT NOT NULL,
 model TEXT NOT NULL,
 platform TEXT NOT NULL,
 refresh_rate INTEGER,
 ram INTEGER,
 resolution TEXT,
 processor TEXT,
 screen_size REAL,
 performance TEXT
);

CREATE TABLE IF NOT EXISTS music_tracks (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 title TEXT NOT NULL,
 artist TEXT DEFAULT '',
 audio_url TEXT NOT NULL,
 is_active INTEGER DEFAULT 0,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`);

function seedAdmin() {
  const email = process.env.ADMIN_EMAIL || "admin@example.com";
  const password = process.env.ADMIN_PASSWORD || "change-me";
  const exists = db.prepare("SELECT id FROM admins WHERE email=?").get(email);
  if (!exists) {
    db.prepare("INSERT INTO admins(email,password_hash) VALUES(?,?)")
      .run(email, bcrypt.hashSync(password, 12));
    console.log(`Admin created: ${email}`);
  }
}
seedAdmin();

function visitorId() {
  return "WARSH-" + crypto.randomBytes(3).toString("hex").toUpperCase();
}

function detectBrowser(ua="") {
  if (/Chrome/i.test(ua)) return "Chrome";
  if (/Firefox/i.test(ua)) return "Firefox";
  if (/Safari/i.test(ua)) return "Safari";
  if (/Edg/i.test(ua)) return "Edge";
  return "UNKNOWN";
}

function detectOS(ua="") {
  if (/Android/i.test(ua)) return "Android";
  if (/iPhone|iPad/i.test(ua)) return "iOS";
  if (/Windows/i.test(ua)) return "Windows";
  if (/Mac OS/i.test(ua)) return "macOS";
  if (/Linux/i.test(ua)) return "Linux";
  return "UNKNOWN";
}

app.post("/api/visitor", (req,res) => {
  const ua = req.headers["user-agent"] || "";
  const supplied = typeof req.body.visitorId === "string" ? req.body.visitorId : null;
  let id = supplied || visitorId();

  const found = db.prepare("SELECT * FROM visitors WHERE visitor_id=?").get(id);
  if (!found) {
    db.prepare(`
      INSERT INTO visitors(visitor_id,user_agent,os,browser,screen,brand,model)
      VALUES(?,?,?,?,?,?,?)
    `).run(id, ua, detectOS(ua), detectBrowser(ua),
      String(req.body.screen || "UNKNOWN"), "UNKNOWN", "UNKNOWN");
  } else {
    db.prepare("UPDATE visitors SET last_active=CURRENT_TIMESTAMP WHERE visitor_id=?").run(id);
  }
  return res.json({ visitorId: id });
});

app.post("/api/event", (req,res) => {
  const { visitorId, type, payload={} } = req.body;
  if (!visitorId || !type) return res.status(400).json({error:"INVALID_EVENT"});
  db.prepare("INSERT INTO events(visitor_id,type,payload) VALUES(?,?,?)")
    .run(visitorId,type,JSON.stringify(payload));
  broadcast({type:"activity", event:{visitorId,type,payload}});
  res.json({ok:true});
});

const brands = ["Apple","Samsung","Xiaomi","Redmi","POCO","OnePlus","OPPO","Realme","Vivo","Huawei","Honor","Tecno","Infinix","Other"];
const devices = [
  ["Apple","iPhone 13","iOS",60,4,"1170x2532","A15 Bionic",6.1,"HIGH"],
  ["Apple","iPhone 15","iOS",60,6,"1179x2556","A16 Bionic",6.1,"HIGH"],
  ["Samsung","Galaxy A16","Android",90,4,"1080x2340","UNKNOWN",6.7,"MEDIUM"],
  ["Samsung","Galaxy A26","Android",120,8,"1080x2340","UNKNOWN",6.7,"HIGH"],
  ["Xiaomi","Redmi Note 13 Pro 4G","Android",120,8,"1080x2400","Helio G99 Ultra",6.67,"HIGH"],
  ["POCO","X7 Pro","Android",120,8,"1220x2712","Dimensity 8400-Ultra",6.67,"ULTRA"],
  ["OnePlus","8","Android",90,8,"1080x2400","Snapdragon 865",6.55,"HIGH"],
  ["Tecno","Spark 30","Android",90,8,"1080x2460","UNKNOWN",6.78,"MEDIUM"]
];
const count = db.prepare("SELECT COUNT(*) c FROM devices").get().c;
if (!count) {
  const ins = db.prepare(`INSERT INTO devices(brand,model,platform,refresh_rate,ram,resolution,processor,screen_size,performance) VALUES(?,?,?,?,?,?,?,?,?)`);
  const tx=db.transaction(rows=>rows.forEach(r=>ins.run(...r))); tx(devices);
}

app.get("/api/devices", (req,res)=>{
  const q=(req.query.q||"").toString().trim();
  const brand=(req.query.brand||"").toString().trim();
  let sql="SELECT * FROM devices WHERE 1=1", args=[];
  if(q){sql+=" AND (brand LIKE ? OR model LIKE ?)"; args.push(`%${q}%`,`%${q}%`);}
  if(brand){sql+=" AND brand=?";args.push(brand);}
  sql+=" ORDER BY brand,model LIMIT 100";
  res.json({brands,devices:db.prepare(sql).all(...args)});
});

function clamp(n,min,max){return Math.max(min,Math.min(max,Math.round(n)));}

function analyze(input) {
  const platform=input.platform==="iOS" ? "iOS" : "Android";
  const range=platform==="iOS" ? [100,180] : [100,200];
  const d=input.deviceProfile||{};
  const performance={LOW:0.78,MEDIUM:0.88,HIGH:0.96,ULTRA:1.02}[d.performance]||0.88;
  const refresh=Math.max(60,Number(d.refresh_rate)||60);
  const refreshFactor=0.92+Math.min(refresh,144)/144*0.10;
  const play={
    HEADSHOT:{speed:1.00,control:1.04,head:1.12},
    "DRAG SHOT":{speed:1.04,control:.98,head:1.08},
    "ONE TAP":{speed:.96,control:1.10,head:1.10},
    AGGRESSIVE:{speed:1.08,control:.94,head:1.02},
    BALANCED:{speed:1.00,control:1.00,head:1.00},
    "CLOSE RANGE":{speed:1.09,control:.95,head:1.03},
    "LONG RANGE":{speed:.92,control:1.10,head:1.04},
    CUSTOM:{speed:1.00,control:1.00,head:1.00}
  }[input.playstyle]||{speed:1,control:1,head:1};

  const aim={LOW:.92,MEDIUM:1,HIGH:1.07}[input.aimSpeed]||1;
  const drag={SHORT:.96,MEDIUM:1,LONG:1.04}[input.dragStyle]||1;
  const control={SOFT:.94,BALANCED:1,FAST:1.06}[input.control]||1;
  const feedback=(input.feedback||[]).reduce((m,f)=>{
    if(f==="TOO FAST")m.speed-=.035;
    if(f==="TOO SLOW")m.speed+=.035;
    if(f==="MORE CONTROL")m.control+=.035;
    if(f==="MORE HEADSHOT")m.head+=.04;
    if(f==="DRAG TOO SENSITIVE")m.speed-=.025;
    if(f==="DRAG TOO SLOW")m.speed+=.025;
    return m;
  },{speed:1,control:1,head:1});

  const base=platform==="iOS"?[140,128,118,105,92,120]:[150,138,125,112,96,125];
  const response=performance*refreshFactor*play.speed*aim*drag*control*feedback.speed;
  const stability=play.control*feedback.control;
  const head=play.head*feedback.head;

  let vals=[
    base[0]*response*head,
    base[1]*response*head*.99,
    base[2]*response*stability,
    base[3]*response*stability*.98,
    base[4]*response*stability*.90,
    base[5]*response*.96
  ].map(v=>clamp(v,range[0],range[1]));

  const dpi=platform==="iOS" ? null : clamp(Math.round(360*performance*refreshFactor),280,600);
  const scores={
    headshot:clamp(78*head+10,0,100),
    control:clamp(72*stability+15,0,100),
    stability:clamp(75*stability+12,0,100),
    deviceMatch:clamp(72*performance+25,0,100),
    playstyleMatch:clamp(80*play.head+15,0,100),
    precision:clamp(78*stability+12,0,100)
  };
  const optimization=Math.round(Object.values(scores).reduce((a,b)=>a+b,0)/6);
  return {
    general:vals[0],redDot:vals[1],scope2x:vals[2],scope4x:vals[3],
    sniper:vals[4],freeLook:vals[5],dpi,headshotTarget:85,
    scores,optimizationScore:optimization
  };
}

app.post("/api/generate", (req,res)=>{
  try {
    const result=analyze(req.body);
    const provider=process.env.OPENAI_API_KEY||process.env.GEMINI_API_KEY ? "configured-provider-ready" : "local";
    const visitorId=req.body.visitorId||"UNKNOWN";
    const stmt=db.prepare(`
      INSERT INTO sensitivity_profiles
      (visitor_id,device,platform,playstyle,aim_speed,drag_style,control,target_priority,
       general,red_dot,scope_2x,scope_4x,sniper,free_look,dpi,optimization_score,provider)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    `);
    const info=stmt.run(visitorId,req.body.device||"UNKNOWN",req.body.platform||"Android",
      req.body.playstyle,req.body.aimSpeed,req.body.dragStyle,req.body.control,req.body.targetPriority,
      result.general,result.redDot,result.scope2x,result.scope4x,result.sniper,result.freeLook,result.dpi,
      result.optimizationScore,provider);
    db.prepare("INSERT INTO events(visitor_id,type,payload) VALUES(?,?,?)")
      .run(visitorId,"AI PROFILE GENERATED",JSON.stringify({profileId:info.lastInsertRowid}));
    broadcast({type:"activity",event:{visitorId,type:"AI PROFILE GENERATED",payload:{profileId:info.lastInsertRowid}}});
    res.json({...result,id:info.lastInsertRowid,provider});
  } catch(e) {
    console.error(e);
    res.status(500).json({error:"TEMPORARY SERVER ERROR"});
  }
});

app.post("/api/feedback",(req,res)=>{
  const {profileId,visitorId,type}=req.body;
  if(!profileId||!type)return res.status(400).json({error:"INVALID_FEEDBACK"});
  db.prepare("INSERT INTO feedback(profile_id,visitor_id,type) VALUES(?,?,?)").run(profileId,visitorId||"UNKNOWN",type);
  res.json({ok:true});
});

function auth(req,res,next){
  const token=(req.headers.authorization||"").replace("Bearer ","");
  try{req.admin=jwt.verify(token,JWT_SECRET);next();}
  catch{res.status(401).json({error:"UNAUTHORIZED"});}
}

app.post("/api/admin/login",(req,res)=>{
  const {email,password}=req.body;
  const admin=db.prepare("SELECT * FROM admins WHERE email=?").get(email);
  if(!admin||!bcrypt.compareSync(password,admin.password_hash))return res.status(401).json({error:"INVALID_LOGIN"});
  const token=jwt.sign({id:admin.id,email:admin.email,role:admin.role},JWT_SECRET,{expiresIn:"8h"});
  res.json({token});
});

app.get("/api/admin/overview",auth,(req,res)=>{
  const total=db.prepare("SELECT COUNT(*) c FROM visitors").get().c;
  const generated=db.prepare("SELECT COUNT(*) c FROM sensitivity_profiles").get().c;
  const tiktok=db.prepare("SELECT COUNT(*) c FROM visitors WHERE tiktok_connected=1").get().c;
  const topDevice=db.prepare("SELECT device,COUNT(*) c FROM sensitivity_profiles GROUP BY device ORDER BY c DESC LIMIT 1").get();
  const topPlay=db.prepare("SELECT playstyle,COUNT(*) c FROM sensitivity_profiles GROUP BY playstyle ORDER BY c DESC LIMIT 1").get();
  const feedback=db.prepare("SELECT type,COUNT(*) c FROM feedback GROUP BY type ORDER BY c DESC").all();
  res.json({totalVisitors:total,onlineNow:0,tiktokConnected:tiktok,sensitivityGenerated:generated,
    headshotProfiles:db.prepare("SELECT COUNT(*) c FROM sensitivity_profiles WHERE playstyle='HEADSHOT'").get().c,
    topDevice:topDevice||null,topPlaystyle:topPlay||null,feedback});
});

app.get("/api/admin/visitors",auth,(req,res)=>{
  res.json(db.prepare("SELECT * FROM visitors ORDER BY last_active DESC LIMIT 200").all());
});

app.get("/api/admin/events",auth,(req,res)=>{
  res.json(db.prepare("SELECT * FROM events ORDER BY created_at DESC LIMIT 100").all());
});

app.get("/api/admin/profiles",auth,(req,res)=>{
  res.json(db.prepare("SELECT * FROM sensitivity_profiles ORDER BY created_at DESC LIMIT 200").all());
});

const sockets=new Set();
function broadcast(data){
  const msg=JSON.stringify(data);
  sockets.forEach(ws=>{if(ws.readyState===1)ws.send(msg);});
}
wss.on("connection",ws=>{sockets.add(ws);ws.on("close",()=>sockets.delete(ws));});

app.use(express.static(path.join(__dirname,"..","dist")));
app.get("*",(req,res)=>{
  if(req.path.startsWith("/api/")) return res.status(404).end();
  res.sendFile(path.join(__dirname,"..","dist","index.html"));
});

server.listen(PORT,()=>console.log(`𝑾Á𝑹𝑺𝑯 server running on http://localhost:${PORT}`));
