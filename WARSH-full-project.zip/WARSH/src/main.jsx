import React,{useEffect,useState} from "react";
import {createRoot} from "react-dom/client";
import "./style.css";

const API=location.hostname==="localhost"&&location.port!=="3000"
 ? "http://localhost:3000/api" : "/api";

const brands=["Apple","Samsung","Xiaomi","Redmi","POCO","OnePlus","OPPO","Realme","Vivo","Huawei","Honor","Tecno","Infinix","Other"];
const styles=["HEADSHOT","DRAG SHOT","ONE TAP","AGGRESSIVE","BALANCED","CLOSE RANGE","LONG RANGE"];
const feedbacks=["PERFECT","TOO FAST","TOO SLOW","MORE HEADSHOT","MORE CONTROL","DRAG TOO SENSITIVE","DRAG TOO SLOW"];

async function api(path,opts={}){const r=await fetch(API+path,{headers:{"Content-Type":"application/json",...(opts.headers||{})},...opts});if(!r.ok)throw new Error((await r.json().catch(()=>({error:"ERROR"}))).error);return r.json()}

function App(){
 const [visitor,setVisitor]=useState(localStorage.warshVisitor||"");
 const [page,setPage]=useState("home");
 const [brand,setBrand]=useState("Apple");
 const [models,setModels]=useState([]);
 const [model,setModel]=useState("");
 const [search,setSearch]=useState("");
 const [playstyle,setPlaystyle]=useState("HEADSHOT");
 const [aimSpeed,setAimSpeed]=useState("MEDIUM");
 const [dragStyle,setDragStyle]=useState("MEDIUM");
 const [control,setControl]=useState("BALANCED");
 const [targetPriority,setTargetPriority]=useState("HEAD");
 const [result,setResult]=useState(null);
 const [loading,setLoading]=useState(false);
 const [message,setMessage]=useState("");
 const [history,setHistory]=useState([]);
 const [admin,setAdmin]=useState(false);

 useEffect(()=>{api("/visitor",{method:"POST",body:JSON.stringify({visitorId:visitor,screen:`${innerWidth}x${innerHeight}`})}).then(x=>{setVisitor(x.visitorId);localStorage.warshVisitor=x.visitorId}).catch(()=>{})},[]);
 useEffect(()=>{api(`/devices?brand=${encodeURIComponent(brand)}&q=${encodeURIComponent(search)}`).then(x=>setModels(x.devices)).catch(()=>{})},[brand,search]);
 useEffect(()=>{const w=new WebSocket(location.origin.replace(/^http/,"ws"));w.onmessage=()=>{};return()=>w.close()},[]);

 function choosePage(p){setPage(p);window.scrollTo({top:0,behavior:"smooth"})}
 async function generate(){
   setLoading(true);setMessage("");
   const d=models.find(x=>x.model===model)||{};
   try{
    const r=await api("/generate",{method:"POST",body:JSON.stringify({
      visitorId:visitor,device:model||"UNKNOWN",platform:d.platform||"Android",
      deviceProfile:d,playstyle,aimSpeed,dragStyle,control,targetPriority
    })});
    setResult({...r,device:model||"UNKNOWN",playstyle});
    setHistory(h=>[{...r,device:model||"UNKNOWN",playstyle,date:new Date().toLocaleString("tr-TR")},...h]);
    setPage("result");
   }catch(e){setMessage(e.message)}
   setLoading(false);
 }
 async function sendFeedback(type){if(!result)return;try{await api("/feedback",{method:"POST",body:JSON.stringify({profileId:result.id,visitorId:visitor,type})});setMessage("Feedback kaydedildi.");}catch{}}

 return <div className="app">
  <div className="bg-grid"/><div className="particles"/>
  <nav>
   <button className="logo" onClick={()=>choosePage("home")}>𝑾Á𝑹𝑺𝑯</button>
   <div className="navlinks">
    {["home","generator","devices","ai","history"].map((p,i)=><button key={p} onClick={()=>choosePage(p)}>{["ANA SAYFA","AI HASSASİYET","CİHAZLAR","AI SİSTEMİ","GEÇMİŞ"][i]}</button>)}
   </div>
   <button className="start" onClick={()=>choosePage("generator")}>BAŞLA</button>
  </nav>

  {page==="home"&&<main>
   <section className="hero">
    <div>
     <span className="badge">AI POWERED FREE FIRE SENSITIVITY</span>
     <h1>YOUR DEVICE.<br/><em>YOUR AIM.</em><br/>YOUR PRECISION.</h1>
     <p>𝑾Á𝑹𝑺𝑯 cihazını, oyun stilini ve nişan tercihlerini analiz ederek sana özel Free Fire sensitivity profili oluşturur.</p>
     <div className="actions"><button className="primary" onClick={()=>choosePage("generator")}>HASSASİYETİMİ OLUŞTUR</button><button className="secondary" onClick={()=>choosePage("ai")}>AI SİSTEMİNİ KEŞFET</button></div>
     <div className="metrics"><b>MULTI-AI ENGINE</b><b>DEVICE ADAPTIVE</b><b>85% HEADSHOT FOCUS</b><b>PERSONALIZED PROFILE</b></div>
    </div>
    <div className="target"><div className="ring r1"/><div className="ring r2"/><div className="cross">+</div><span>DEVICE SCAN</span><span>AI CORE // 85</span></div>
   </section>
   <section className="cards"><Card t="DEVICE ANALYSIS" d="Cihaz özellikleri ve performans profili engine tarafından değerlendirilir."/><Card t="MULTI-LAYER AI" d="Aim, playstyle, performance ve headshot optimizasyonu birlikte çalışır."/><Card t="FEEDBACK LOOP" d="Test sonrası verdiğin feedback sonraki profile dahil edilir."/></section>
  </main>}

  {page==="generator"&&<Generator {...{brand,setBrand,models,model,setModel,search,setSearch,playstyle,setPlaystyle,aimSpeed,setAimSpeed,dragStyle,setDragStyle,control,setControl,targetPriority,setTargetPriority,generate,loading,message}}/>}
  {page==="result"&&result&&<Result r={result} onFeedback={sendFeedback} message={message}/>}
  {page==="devices"&&<Devices models={models} choose={(m)=>{setModel(m);choosePage("generator")}}/>}
  {page==="ai"&&<AI/>}
  {page==="history"&&<History history={history}/>}
 </div>
}

function Card({t,d}){return <article className="card"><small>{t}</small><h3>𝑾Á𝑹𝑺𝑯 ENGINE</h3><p>{d}</p></article>}

function Generator(p){
 return <main className="page"><span className="badge">SENSITIVITY ENGINE / V1</span><h2>AI HASSASİYET<br/><em>GENERATOR</em></h2>
 <div className="steps"><b>01 DEVICE</b><b>02 PLAYSTYLE</b><b>03 AIM PROFILE</b><b>04 OPTIMIZATION</b></div>
 <div className="formgrid">
  <label>MARKA<select value={p.brand} onChange={e=>p.setBrand(e.target.value)}>{brands.map(x=><option key={x}>{x}</option>)}</select></label>
  <label>MODEL<input value={p.search} onChange={e=>p.setSearch(e.target.value)} placeholder="Search your device..."/><select value={p.model} onChange={e=>p.setModel(e.target.value)}><option value="">Cihaz seç</option>{p.models.map(x=><option key={x.id} value={x.model}>{x.model}</option>)}</select></label>
  <Select title="PLAYSTYLE" value={p.playstyle} set={p.setPlaystyle} items={styles}/>
  <Select title="AIM SPEED" value={p.aimSpeed} set={p.setAimSpeed} items={["LOW","MEDIUM","HIGH"]}/>
  <Select title="DRAG STYLE" value={p.dragStyle} set={p.setDragStyle} items={["SHORT","MEDIUM","LONG"]}/>
  <Select title="CONTROL" value={p.control} set={p.setControl} items={["SOFT","BALANCED","FAST"]}/>
  <Select title="TARGET PRIORITY" value={p.targetPriority} set={p.setTargetPriority} items={["HEAD","BODY","BALANCED"]}/>
 </div>
 {p.message&&<div className="error">{p.message}</div>}
 <button className="generate" disabled={p.loading} onClick={p.generate}>{p.loading?"RUNNING ENSEMBLE...":"HASSASİYETİMİ OLUŞTUR →"}</button>
 <p className="note">85% HEADSHOT FOCUS bir optimizasyon hedefidir; kesin isabet garantisi değildir.</p>
 </main>
}
function Select({title,value,set,items}){return <label>{title}<select value={value} onChange={e=>set(e.target.value)}>{items.map(x=><option key={x}>{x}</option>)}</select></label>}

function Result({r,onFeedback,message}){
 return <main className="page"><span className="badge">𝑾Á𝑹𝑺𝑯 / AI OPTIMIZED SENSITIVITY</span><h2>{r.device}<br/><em>{r.playstyle}</em></h2>
 <div className="score"><strong>{r.headshotTarget}%</strong><span>HEADSHOT OPTIMIZATION TARGET</span></div>
 <div className="sensgrid">{[["GENERAL",r.general],["RED DOT",r.redDot],["2X",r.scope2x],["4X",r.scope4x],["SNIPER",r.sniper],["FREE LOOK",r.freeLook],["DPI",r.dpi??"N/A"]].map(([k,v])=><div className="sens" key={k}><small>{k}</small><strong>{v}</strong></div>)}</div>
 <div className="scoregrid">{Object.entries(r.scores).map(([k,v])=><div key={k}><span>{k.replace(/([A-Z])/g," $1")}</span><b>{Math.round(v)}%</b><i><u style={{width:`${v}%`}}/></i></div>)}</div>
 <button className="primary" onClick={()=>navigator.clipboard?.writeText(`𝑾Á𝑹𝑺𝑯 AI SENSITIVITY\nDEVICE: ${r.device}\nPROFILE: ${r.playstyle}\nGENERAL: ${r.general}\nRED DOT: ${r.redDot}\n2X: ${r.scope2x}\n4X: ${r.scope4x}\nSNIPER: ${r.sniper}\nFREE LOOK: ${r.freeLook}\nDPI: ${r.dpi??"N/A"}\nHEADSHOT FOCUS: 85%`)}>KOPYALA</button>
 <h3>FEEDBACK</h3><div className="feedback">{feedbacks.map(f=><button onClick={()=>onFeedback(f)} key={f}>{f}</button>)}</div>{message&&<p>{message}</p>}
 </main>
}
function Devices({models,choose}){return <main className="page"><span className="badge">DEVICE EXPLORER</span><h2>SUPPORTED<br/><em>DEVICES</em></h2><div className="devicegrid">{models.map(d=><div className="card" key={d.id}><small>{d.brand}</small><h3>{d.model}</h3><p>{d.refresh_rate||"UNKNOWN"}Hz · {d.ram||"UNKNOWN"}GB RAM</p><button className="secondary" onClick={()=>choose(d.model)}>HASSASİYET OLUŞTUR</button></div>)}</div></main>}
function AI(){return <main className="page"><span className="badge">MULTI-LAYER AI ENGINE</span><h2>ANALYSIS<br/><em>PIPELINE</em></h2><div className="pipeline">{["DEVICE AI","AIM AI","PERFORMANCE AI","PLAYSTYLE AI","HEADSHOT AI","ENSEMBLE","FINAL OPTIMIZER"].map((x,i)=><div key={x}><strong>0{i+1}</strong><span>{x}</span></div>)}</div></main>}
function History({history}){return <main className="page"><span className="badge">PROFILE HISTORY</span><h2>SAVED<br/><em>PROFILES</em></h2>{history.length===0?<div className="card">NO DATA</div>:<div className="history">{history.map((x,i)=><div className="card" key={i}><small>{x.date}</small><h3>{x.device}</h3><p>{x.playstyle} · General {x.general} · Red Dot {x.redDot}</p></div>)}</div>}</main>}

function Admin(){
 return null
}
function Root(){return <App/>}
createRoot(document.getElementById("root")).render(<Root/>);
